# Лабораторная работа №5

Основана на лабораторной работе №4: авторизация и API.

## Использовано:
- Backend: FastAPI (на базе кода из ЛР4)
- Frontend: HTML + JS
- SQLite вместо MySQL
- Nginx для проксирования
- Docker + docker-compose

## Запуск:
```bash
docker-compose up --build
```

## Автор:
Киселев К.С.
